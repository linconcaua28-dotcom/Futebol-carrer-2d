package com.lc.futebolcarreira;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894|1024|512); setContentView(new GameView(this)); }

    static class GameView extends View {
        Paint p = new Paint(3);
        float px=0.25f, py=0.5f, bx=0.5f, by=0.5f, joyX, joyY;
        boolean joy=false; int score=0; String mode="CARREIRA DE JOGADOR";
        String action="Use o joystick para se movimentar";
        long last=System.currentTimeMillis();
        HashMap<Integer,Boolean> held=new HashMap<>();
        GameView(Context c){super(c); setFocusable(true);}
        void color(Canvas c,int col){p.setColor(col);}
        @Override protected void onDraw(Canvas c){
            float w=getWidth(),h=getHeight();
            c.drawColor(Color.rgb(20,105,48));
            p.setColor(Color.rgb(30,145,65)); c.drawRect(0,h*.08f,w,h*.92f,p);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
            c.drawRect(w*.06f,h*.12f,w*.94f,h*.88f,p); c.drawLine(w/2,h*.12f,w/2,h*.88f,p); c.drawCircle(w/2,h/2,h*.16f,p);
            c.drawRect(w*.06f,h*.34f,w*.18f,h*.66f,p); c.drawRect(w*.82f,h*.34f,w*.94f,h*.66f,p);
            p.setStyle(Paint.Style.FILL);
            // bola e jogador
            p.setColor(Color.WHITE); c.drawCircle(bx*w,by*h,Math.max(7,h*.018f),p);
            p.setColor(Color.rgb(30,100,245)); c.drawCircle(px*w,py*h,h*.035f,p);
            p.setColor(Color.WHITE); p.setTextSize(h*.035f); c.drawText("VOCÊ",px*w-h*.035f,py*h-h*.05f,p);
            // placar
            p.setColor(Color.argb(220,0,0,0)); c.drawRoundRect(w*.36f,h*.015f,w*.64f,h*.09f,12,12,p);
            p.setColor(Color.WHITE); p.setTextSize(h*.04f); c.drawText("SEU TIME  "+score+" x 0  ADV",w*.405f,h*.067f,p);
            c.drawText(mode,w*.02f,h*.06f,p);
            c.setTextSize(h*.027f); c.drawText(action,w*.34f,h*.96f,p);
            // joystick
            p.setColor(Color.argb(90,255,255,255)); c.drawCircle(w*.13f,h*.76f,h*.105f,p);
            p.setColor(Color.argb(180,255,255,255)); c.drawCircle(w*.13f+(joy?joyX:0),h*.76f+(joy?joyY:0),h*.045f,p);
            button(c,w*.72f,h*.72f,h*.07f,"PASSE"); button(c,w*.84f,h*.72f,h*.07f,"CHUTE");
            button(c,w*.72f,h*.52f,h*.07f,"COLOC."); button(c,w*.84f,h*.52f,h*.07f,"SUPER");
            button(c,w*.92f,h*.34f,h*.045f,"PEDIR");
            long now=System.currentTimeMillis(); float dt=Math.min(.05f,(now-last)/1000f); last=now;
            if(joy){px=Math.max(.08f,Math.min(.92f,px+joyX/(h*.105f)*dt*.55f)); py=Math.max(.14f,Math.min(.86f,py+joyY/(h*.105f)*dt*.55f));}
            if(Math.hypot(px-bx,py-by)<.055){bx=Math.min(.9f,bx+.002f); }
            postInvalidateDelayed(16);
        }
        void button(Canvas c,float x,float y,float r,String t){p.setColor(Color.argb(190,15,25,35)); c.drawCircle(x,y,r,p); p.setColor(Color.WHITE); p.setTextSize(r*.38f); p.setTextAlign(Paint.Align.CENTER); c.drawText(t,x,y+r*.12f,p); p.setTextAlign(Paint.Align.LEFT);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){
                if(x<w*.27f && y>h*.55f){joy=true; joyX=Math.max(-h*.07f,Math.min(h*.07f,x-w*.13f)); joyY=Math.max(-h*.07f,Math.min(h*.07f,y-h*.76f));}
                else if(e.getAction()==MotionEvent.ACTION_DOWN){
                    if(x>w*.79f&&y>h*.43f&&y<h*.62f){action="SUPER CHUTE!"; bx=Math.min(.92f,bx+.18f); score++;}
                    else if(x>w*.79f&&y>h*.63f){action="Chute realizado"; bx=Math.min(.92f,bx+.12f);}
                    else if(x>w*.67f&&y>h*.63f){action="Passe realizado"; bx=Math.min(.92f,bx+.07f);}
                    else if(x>w*.67f&&y>h*.43f){action="Chute colocado!"; bx=Math.min(.92f,bx+.10f);}
                    else if(x>w*.87f&&y<h*.48f){action="Você pediu a bola!";}
                }
            } else if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){joy=false; joyX=joyY=0;}
            invalidate(); return true;
        }
    }
}
