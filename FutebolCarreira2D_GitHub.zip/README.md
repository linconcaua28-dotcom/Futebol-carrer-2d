# Futebol Carreira 2D — projeto inicial

Projeto Android nativo em Java, orientação horizontal, compatível com Android 16 (API 36).
Inclui campo 2D, jogador, bola, joystick touch e botões de passe, chute, chute colocado,
super chute e pedir passe. O workflow GitHub Actions compila o APK de depuração.

## Gerar APK pelo GitHub
1. Envie todos os arquivos desta pasta para a raiz de um repositório GitHub.
2. Abra a aba **Actions**.
3. Selecione **Build APK Android 16** e clique em **Run workflow** (ou faça um push na branch main).
4. Quando terminar, abra a execução e baixe o artifact **FutebolCarreira2D-APK**.

## Observação
Esta é uma base jogável/protótipo. As ligas do mundo, temporadas, transferências, IA de adversários,
animações e progressão completa de carreira ainda precisam ser implementadas. Não inclui clubes,
escudos ou elencos oficiais licenciados.
